define(['core/ajax', 'core/notification', 'mod_studymark/highlighter'], function(Ajax, Notification, Highlighter) {
    const call = (method, args) => Ajax.call([{methodname: method, args}])[0];
    const escape = value => { const e=document.createElement('div'); e.textContent=value || ''; return e.innerHTML; };
    async function init(config) {
        const root=document.getElementById('studymark-app');
        root.innerHTML='<div class="studymark-layout"><aside class="studymark-documents"><h3>Documentos</h3><div data-region="documents"></div></aside><main class="studymark-reader"><div data-region="viewer" class="studymark-empty">Selecciona un documento</div></main><aside class="studymark-annotations"><h3>Subrayados</h3><div data-region="highlights"></div><h3>Comentarios</h3><form data-region="comment-form"><textarea class="form-control" rows="2" aria-label="Comentario"></textarea><button class="btn btn-primary btn-sm mt-2">Añadir</button></form><div data-region="comments"></div></aside></div>';
        const docsRegion=root.querySelector('[data-region=documents]');
        const viewer=root.querySelector('[data-region=viewer]');
        const highlightsRegion=root.querySelector('[data-region=highlights]');
        const commentsRegion=root.querySelector('[data-region=comments]');
        let current=null, highlighter=null, highlights=[];
        const documents=await call('mod_studymark_get_documents',{cmid:config.cmid}).catch(Notification.exception);
        docsRegion.innerHTML=documents.length ? documents.map(d=>`<button class="studymark-document" data-id="${d.id}">${escape(d.title)}<small>${escape(d.mimetype)}</small></button>`).join('') : '<p class="text-muted">No hay documentos.</p>';
        async function renderAnnotations() {
            highlightsRegion.innerHTML=highlights.length ? highlights.map(h=>`<article class="studymark-highlight"><span class="studymark-swatch" style="background:${escape(h.color)}"></span><q>${escape(h.selectedtext)}</q><small>${escape(h.userfullname)}</small>${h.canedit?`<button data-delete-highlight="${h.id}" aria-label="Eliminar">×</button>`:''}</article>`).join('') : '<p class="text-muted">Todavía no hay subrayados.</p>';
            const comments=await call('mod_studymark_get_comments',{cmid:config.cmid,documentid:current.id,groupid:0});
            commentsRegion.innerHTML=comments.map(c=>`<article class="studymark-comment"><strong>${escape(c.userfullname)}</strong><p>${escape(c.content)}</p>${c.canedit?`<button data-delete-comment="${c.id}" class="btn btn-link btn-sm">Eliminar</button>`:''}</article>`).join('');
        }
        async function openDocument(doc) {
            current=doc; if (highlighter) highlighter.destroy();
            highlights=await call('mod_studymark_get_highlights',{cmid:config.cmid,documentid:doc.id,groupid:0});
            if (/pdf/i.test(doc.mimetype)) { viewer.innerHTML=`<object data="${doc.url}" type="application/pdf"><a href="${doc.url}">Abrir PDF</a></object>`; }
            else if (/text|html/i.test(doc.mimetype)) {
                const response=await fetch(doc.url,{credentials:'same-origin'}); const raw=await response.text();
                const text=/html/i.test(doc.mimetype) ? new DOMParser().parseFromString(raw,'text/html').body.textContent : raw;
                viewer.innerHTML=''; const article=document.createElement('article'); article.className='studymark-text'; article.textContent=text; viewer.append(article);
                if (config.canhighlight) highlighter=new Highlighter(article, async data=>{ const saved=await call('mod_studymark_create_highlight',{cmid:config.cmid,documentid:doc.id,groupid:0,pagenumber:0,note:'',headingcontext:'',shared:false,...data}); highlights.push(saved); highlighter.apply([saved]); await renderAnnotations(); });
                if (highlighter) highlighter.apply(highlights);
            } else { viewer.innerHTML=`<div class="studymark-empty"><p>La previsualización EPUB se incorporará en la siguiente iteración.</p><a class="btn btn-primary" href="${doc.url}">Descargar documento</a></div>`; }
            await renderAnnotations();
        }
        docsRegion.addEventListener('click',e=>{const button=e.target.closest('[data-id]'); if(button) openDocument(documents.find(d=>d.id==button.dataset.id)).catch(Notification.exception);});
        root.addEventListener('click',async e=>{ if(e.target.dataset.deleteHighlight){await call('mod_studymark_delete_highlight',{cmid:config.cmid,highlightid:+e.target.dataset.deleteHighlight}); return openDocument(current);} if(e.target.dataset.deleteComment){await call('mod_studymark_delete_comment',{cmid:config.cmid,commentid:+e.target.dataset.deleteComment}); return renderAnnotations();} });
        root.querySelector('[data-region=comment-form]').addEventListener('submit',async e=>{e.preventDefault(); if(!current)return; const field=e.target.querySelector('textarea'); if(!field.value.trim())return; await call('mod_studymark_create_comment',{cmid:config.cmid,documentid:current.id,highlightid:0,groupid:0,content:field.value}); field.value=''; await renderAnnotations();});
        if(documents.length) await openDocument(documents[0]);
    }
    return {init};
});

