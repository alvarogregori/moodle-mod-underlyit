<?php
defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot . '/course/moodleform_mod.php');

class mod_studymark_mod_form extends moodleform_mod {
    public function definition() {
        $mform = $this->_form;
        $mform->addElement('text', 'name', get_string('studymarkname', 'studymark'), ['size' => 64]);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', null, 'required', null, 'client');
        $this->standard_intro_elements();
        $mform->addElement('filemanager', 'documents', get_string('documents', 'studymark'), null, [
            'subdirs' => 0, 'maxbytes' => 0, 'maxfiles' => 50,
            'accepted_types' => ['.pdf', '.epub', '.html', '.htm', '.txt'],
        ]);
        $this->standard_coursemodule_elements();
        $this->add_action_buttons();
    }

    public function data_preprocessing(&$defaultvalues) {
        if (!empty($this->current->instance)) {
            $draftitemid = file_get_submitted_draft_itemid('documents');
            file_prepare_draft_area($draftitemid, $this->context->id, 'mod_studymark', 'documents', 0, [
                'subdirs' => 0, 'maxfiles' => 50,
            ]);
            $defaultvalues['documents'] = $draftitemid;
        }
    }
}

