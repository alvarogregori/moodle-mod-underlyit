<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_studymark';
$plugin->version = 2026101810;
$plugin->requires = 2022112800;
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = '0.4.1 (MVP)';

