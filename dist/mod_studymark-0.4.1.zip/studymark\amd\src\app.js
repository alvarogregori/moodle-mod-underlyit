define(['core/ajax', 'core/notification', 'mod_studymark/highlighter', 'mod_studymark/pdfviewer'], function(Ajax, Notification, Highlighter, PdfViewer) {
    const call = (method, args) => Ajax.call([{methodname: method, args}])[0];
    const escape = value => { const node = document.createElement('div'); node.textContent = value || ''; return node.innerHTML; };

    async function init(config) {
        const root = document.getElementById('studymark-app');
        if (window.matchMedia('(max-width: 900px)').matches) root.classList.add('studymark-focus');
        root.innerHTML = '<div class="studymark-focusbar"><strong>StudyMark</strong><span><a class="btn btn-secondary btn-sm mr-2" href="' + config.courseurl + '">Salir</a><button type="button" class="btn btn-secondary btn-sm" data-action="toggle-focus">Alternar pantalla completa</button></span></div><div class="studymark-layout studymark-single">' +
            '<main class="studymark-reader"><div data-region="viewer" class="studymark-empty">Cargando documentoÃ¢â‚¬Â¦</div></main>' +
            '<aside class="studymark-annotations"><h3>Subrayados</h3><div data-region="highlights"></div>' +
            '<h3>Comentarios</h3><form data-region="comment-form"><textarea class="form-control" rows="2" aria-label="Comentario"></textarea>' +
            '<button class="btn btn-primary btn-sm mt-2">AÃƒÂ±adir</button></form><div data-region="comments"></div></aside></div>';
        const viewer = root.querySelector('[data-region=viewer]');
        const highlightsRegion = root.querySelector('[data-region=highlights]');
        const commentsRegion = root.querySelector('[data-region=comments]');
        let documentRecord = null;
        let highlighter = null;
        let pdfViewer = null;
        let highlights = [];

        async function renderAnnotations() {
            highlightsRegion.innerHTML = highlights.length ? highlights.map(item =>
                `<article class="studymark-highlight"><span class="studymark-swatch" style="background:${escape(item.color)}"></span>` +
                `<q>${escape(item.selectedtext)}</q><small>${escape(item.userfullname)}</small>` +
                `${item.canedit ? `<button data-delete-highlight="${item.id}" aria-label="Eliminar">Ãƒâ€”</button>` : ''}</article>`
            ).join('') : '<p class="text-muted">TodavÃƒÂ­a no hay subrayados.</p>';
            const comments = await call('mod_studymark_get_comments', {cmid: config.cmid, documentid: documentRecord.id, groupid: 0});
            commentsRegion.innerHTML = comments.map(comment =>
                `<article class="studymark-comment"><strong>${escape(comment.userfullname)}</strong><p>${escape(comment.content)}</p>` +
                `${comment.canedit ? `<button data-delete-comment="${comment.id}" class="btn btn-link btn-sm">Eliminar</button>` : ''}</article>`
            ).join('');
        }

        async function renderPdf() {
            viewer.classList.remove('studymark-empty');
            viewer.innerHTML = '<div class="studymark-pdfjs"></div>';
            pdfViewer = new PdfViewer(viewer.querySelector('.studymark-pdfjs'), {
                url: documentRecord.url, workerUrl: config.pdfworkerurl, highlights, canHighlight: config.canhighlight,
                onSave: async data => {
                    const saved = await call('mod_studymark_create_highlight', {cmid: config.cmid, documentid: documentRecord.id, groupid: 0, ...data});
                    highlights.push(saved);
                    await renderAnnotations();
                    return saved;
                }
            });
            await pdfViewer.init();
        }

        async function openDocument() {
            highlights = await call('mod_studymark_get_highlights', {cmid: config.cmid, documentid: documentRecord.id, groupid: 0});
            if (/pdf/i.test(documentRecord.mimetype)) {
                await renderPdf();
            } else if (/text|html/i.test(documentRecord.mimetype)) {
                const response = await fetch(documentRecord.url, {credentials: 'same-origin'});
                const raw = await response.text();
                const text = /html/i.test(documentRecord.mimetype) ? new DOMParser().parseFromString(raw, 'text/html').body.textContent : raw;
                viewer.innerHTML = '';
                const article = document.createElement('article');
                article.className = 'studymark-text';
                article.textContent = text;
                viewer.append(article);
                if (config.canhighlight) {
                    highlighter = new Highlighter(article, async data => {
                        const saved = await call('mod_studymark_create_highlight', {cmid: config.cmid, documentid: documentRecord.id, groupid: 0, pagenumber: 0, note: '', headingcontext: '', shared: false, ...data});
                        highlights.push(saved);
                        highlighter.apply([saved]);
                        await renderAnnotations();
                    });
                    highlighter.apply(highlights);
                }
            } else {
                viewer.innerHTML = `<div class="studymark-empty"><p>La previsualizaciÃƒÂ³n EPUB se incorporarÃƒÂ¡ en la siguiente iteraciÃƒÂ³n.</p><a class="btn btn-primary" href="${documentRecord.url}">Descargar documento</a></div>`;
            }
            await renderAnnotations();
        }

        try {
            const documents = await call('mod_studymark_get_documents', {cmid: config.cmid});
            documentRecord = documents[0] || null;
            if (!documentRecord) {
                viewer.innerHTML = '<div class="studymark-empty"><p>Esta actividad todavÃƒÂ­a no tiene documento.</p></div>';
                root.querySelector('.studymark-annotations').hidden = true;
                return;
            }
            await openDocument();
        } catch (error) {
            viewer.innerHTML = '<div class="alert alert-danger m-3">No se pudo cargar el documento.</div>';
            Notification.exception(error);
        }

        root.addEventListener('click', async event => {
            if (event.target.dataset.action === 'toggle-focus') { root.classList.toggle('studymark-focus'); return; }
            if (event.target.dataset.deleteHighlight) {
                await call('mod_studymark_delete_highlight', {cmid: config.cmid, highlightid: +event.target.dataset.deleteHighlight});
                return openDocument();
            }
            if (event.target.dataset.deleteComment) {
                await call('mod_studymark_delete_comment', {cmid: config.cmid, commentid: +event.target.dataset.deleteComment});
                return renderAnnotations();
            }
        });
        root.querySelector('[data-region=comment-form]').addEventListener('submit', async event => {
            event.preventDefault();
            const field = event.target.querySelector('textarea');
            if (!field.value.trim()) return;
            await call('mod_studymark_create_comment', {cmid: config.cmid, documentid: documentRecord.id, highlightid: 0, groupid: 0, content: field.value});
            field.value = '';
            await renderAnnotations();
        });
    }
    return {init};
});
