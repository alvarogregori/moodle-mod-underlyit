<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_studymark_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    if ($oldversion < 2026101802) {
        $table = new xmldb_table('studymark_document');
        $oldindex = new xmldb_index('activity_filename', XMLDB_INDEX_UNIQUE, ['studymarkid', 'filename']);
        if ($dbman->index_exists($table, $oldindex)) {
            $dbman->drop_index($table, $oldindex);
        }
        $newindex = new xmldb_index('activity_unique', XMLDB_INDEX_UNIQUE, ['studymarkid']);
        if (!$dbman->index_exists($table, $newindex)) {
            $dbman->add_index($table, $newindex);
        }
        upgrade_mod_savepoint(true, 2026101802, 'studymark');
    }
    return true;
}
