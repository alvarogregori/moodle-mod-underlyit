define([], function() {
    class Highlighter {
        constructor(container, onSave) {
            this.container = container;
            this.onSave = onSave;
            this.mouseup = this.handleSelection.bind(this);
            container.addEventListener('mouseup', this.mouseup);
        }
        destroy() { this.container.removeEventListener('mouseup', this.mouseup); }
        offsets(range) {
            const before = document.createRange();
            before.selectNodeContents(this.container);
            before.setEnd(range.startContainer, range.startOffset);
            return {type: 'text-offset', start: before.toString().length, end: before.toString().length + range.toString().length};
        }
        handleSelection() {
            const selection = window.getSelection();
            if (!selection || selection.isCollapsed || !selection.rangeCount) return;
            const range = selection.getRangeAt(0);
            if (!this.container.contains(range.commonAncestorContainer)) return;
            const text = selection.toString().trim();
            if (!text) return;
            this.onSave({selectedtext: text, selectorjson: JSON.stringify(this.offsets(range)), color: '#fff176', positionorder: this.offsets(range).start});
            selection.removeAllRanges();
        }
        apply(items) {
            [...items].sort((a,b) => b.positionorder-a.positionorder).forEach(item => {
                if (this.container.querySelector(`[data-highlight-id="${item.id}"]`)) return;
                const range = this.rangeFromOffsets(item.positionorder, item.positionorder + item.selectedtext.length);
                if (!range) return;
                const mark = document.createElement('mark');
                mark.dataset.highlightId = item.id;
                mark.style.backgroundColor = item.color;
                mark.title = item.note || item.userfullname;
                try { range.surroundContents(mark); } catch (e) { /* Cross-node ranges remain listed in the sidebar. */ }
            });
        }
        rangeFromOffsets(start, end) {
            const walker = document.createTreeWalker(this.container, NodeFilter.SHOW_TEXT);
            let node, offset = 0, startNode, startOffset, endNode, endOffset;
            while ((node = walker.nextNode())) {
                const next = offset + node.nodeValue.length;
                if (!startNode && start >= offset && start <= next) { startNode=node; startOffset=start-offset; }
                if (end >= offset && end <= next) { endNode=node; endOffset=end-offset; break; }
                offset = next;
            }
            if (!startNode || !endNode) return null;
            const range=document.createRange(); range.setStart(startNode,startOffset); range.setEnd(endNode,endOffset); return range;
        }
    }
    return Highlighter;
});

