<?php
$string['pluginname'] = 'StudyMark';
$string['modulename'] = 'StudyMark';
$string['modulenameplural'] = 'StudyMark activities';
$string['pluginadministration'] = 'StudyMark administration';
$string['studymarkname'] = 'Activity name';
$string['studymarkname_help'] = 'Name of the collaborative reading activity.';
$string['documents'] = 'Documents';
$string['documents_help'] = 'PDF, EPUB, HTML or plain-text documents available in this activity.';
$string['groupmode'] = 'Use Moodle course groups to control shared annotations.';
$string['privacy:metadata:studymark_document'] = 'Stores document metadata and uploader identity.';
$string['privacy:metadata:studymark_highlight'] = 'Stores highlights made by learners.';
$string['privacy:metadata:studymark_comment'] = 'Stores comments made by learners.';
$string['privacy:metadata:userid'] = 'The Moodle user ID.';
$string['privacy:metadata:content'] = 'User-authored annotation content.';
$string['eventactivityviewed'] = 'StudyMark activity viewed';
$string['eventhighlightcreated'] = 'Highlight created';
$string['eventcommentcreated'] = 'Comment created';
$string['errorinvaliddocument'] = 'The requested document is not available in this activity.';

