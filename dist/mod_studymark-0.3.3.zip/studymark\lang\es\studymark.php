<?php
$string['pluginname'] = 'StudyMark';
$string['modulename'] = 'StudyMark';
$string['modulenameplural'] = 'Actividades StudyMark';
$string['pluginadministration'] = 'Administración de StudyMark';
$string['studymarkname'] = 'Nombre de la actividad';
$string['studymarkname_help'] = 'Nombre de la actividad de lectura colaborativa.';
$string['documents'] = 'Documentos';
$string['documents_help'] = 'Documentos PDF, EPUB, HTML o texto disponibles en la actividad.';
$string['groupmode'] = 'Usa los grupos del curso de Moodle para controlar las anotaciones compartidas.';
$string['privacy:metadata:studymark_document'] = 'Almacena metadatos del documento y la identidad de quien lo subió.';
$string['privacy:metadata:studymark_highlight'] = 'Almacena los subrayados del alumnado.';
$string['privacy:metadata:studymark_comment'] = 'Almacena los comentarios del alumnado.';
$string['privacy:metadata:userid'] = 'El ID de usuario de Moodle.';
$string['privacy:metadata:content'] = 'Contenido de anotaciones creado por el usuario.';
$string['eventactivityviewed'] = 'Actividad StudyMark vista';
$string['eventhighlightcreated'] = 'Subrayado creado';
$string['eventcommentcreated'] = 'Comentario creado';
$string['errorinvaliddocument'] = 'El documento solicitado no está disponible en esta actividad.';

