﻿define(['core/ajax', 'core/notification', 'mod_studymark/highlighter', 'mod_studymark/documentreader'], function(Ajax, Notification, Highlighter, DocumentReader) {
    const call = (method, args) => Ajax.call([{methodname: method, args}])[0];
    const escape = value => { const node = document.createElement('div'); node.textContent = value || ''; return node.innerHTML; };

    async function init(config) {
        const root = document.getElementById('studymark-app');
        if (window.matchMedia('(max-width: 900px)').matches) root.classList.add('studymark-focus');
        root.innerHTML = '<div class="studymark-focusbar"><strong>StudyMark</strong><span class="studymark-reader-actions">' +
            '<button type="button" class="btn btn-secondary btn-sm" data-action="summary" disabled>Lectura abreviada</button>' +
            '<a class="btn btn-secondary btn-sm" data-action="original" href="#">Documento original</a>' +
            '<a class="btn btn-secondary btn-sm" href="' + config.courseurl + '">Salir</a>' +
            '<button type="button" class="btn btn-secondary btn-sm" data-action="toggle-focus">Alternar pantalla completa</button></span></div>' +
            '<div class="studymark-layout studymark-single"><main class="studymark-reader"><div data-region="viewer" class="studymark-empty">Cargando documento…</div></main>' +
            '<aside class="studymark-annotations"><h3>Subrayados</h3><div data-region="highlights"></div>' +
            '<h3>Comentarios</h3><form data-region="comment-form"><textarea class="form-control" rows="2" aria-label="Comentario"></textarea>' +
            '<button class="btn btn-primary btn-sm mt-2">Añadir</button></form><div data-region="comments"></div></aside></div>';
        const viewer = root.querySelector('[data-region=viewer]');
        const highlightsRegion = root.querySelector('[data-region=highlights]');
        const commentsRegion = root.querySelector('[data-region=comments]');
        const summaryButton = root.querySelector('[data-action=summary]');
        let documentRecord = null;
        let highlighter = null;
        let highlights = [];
        let readingArticle = null;
        let summaryMode = false;

        async function renderAnnotations() {
            highlightsRegion.innerHTML = highlights.length ? highlights.map(item =>
                `<article class="studymark-highlight"><span class="studymark-swatch" style="background:${escape(item.color)}"></span>` +
                `<q>${escape(item.selectedtext)}</q><small>${escape(item.userfullname)}</small>` +
                `${item.canedit ? `<button data-delete-highlight="${item.id}" aria-label="Eliminar">×</button>` : ''}</article>`
            ).join('') : '<p class="text-muted">Todavía no hay subrayados.</p>';
            const comments = await call('mod_studymark_get_comments', {cmid: config.cmid, documentid: documentRecord.id, groupid: 0});
            commentsRegion.innerHTML = comments.map(comment =>
                `<article class="studymark-comment"><strong>${escape(comment.userfullname)}</strong><p>${escape(comment.content)}</p>` +
                `${comment.canedit ? `<button data-delete-comment="${comment.id}" class="btn btn-link btn-sm">Eliminar</button>` : ''}</article>`
            ).join('');
        }

        function buildSummary() {
            const summary = document.createElement('article');
            summary.className = 'studymark-reading-document studymark-reading-summary';
            const headings = [];
            const emitted = new Set();
            Array.from(readingArticle.children).forEach(block => {
                const match = block.tagName.match(/^H([1-6])$/);
                if (match) {
                    const level = +match[1]; headings.splice(level - 1); headings[level - 1] = block;
                    return;
                }
                if (!block.querySelector('mark[data-highlight-id]')) return;
                headings.forEach(heading => {
                    if (heading && !emitted.has(heading.dataset.blockId)) {
                        summary.append(heading.cloneNode(true)); emitted.add(heading.dataset.blockId);
                    }
                });
                summary.append(block.cloneNode(true));
            });
            if (!summary.children.length) summary.innerHTML = '<p class="studymark-summary-empty">Aún no hay subrayados para construir la lectura abreviada.</p>';
            return summary;
        }

        function renderMode() {
            viewer.replaceChildren(summaryMode ? buildSummary() : readingArticle);
            summaryButton.textContent = summaryMode ? 'Lectura completa' : 'Lectura abreviada';
            summaryButton.setAttribute('aria-pressed', String(summaryMode));
        }

        async function openDocument() {
            highlights = await call('mod_studymark_get_highlights', {cmid: config.cmid, documentid: documentRecord.id, groupid: 0});
            viewer.className = 'studymark-reading-host';
            const reader = new DocumentReader({
                url: documentRecord.url, filename: documentRecord.filename, mimetype: documentRecord.mimetype,
                workerUrl: config.pdfworkerurl, progress: message => { viewer.innerHTML = `<div class="studymark-reading-progress">${escape(message)}</div>`; }
            });
            readingArticle = await reader.load();
            if (config.canhighlight) {
                highlighter = new Highlighter(readingArticle, async data => {
                    const saved = await call('mod_studymark_create_highlight', {
                        cmid: config.cmid, documentid: documentRecord.id, groupid: 0, pagenumber: 0,
                        note: '', headingcontext: '', shared: false, ...data
                    });
                    highlights.push(saved);
                    highlighter.apply([saved]);
                    await renderAnnotations();
                });
                highlighter.apply(highlights);
            }
            summaryButton.disabled = false;
            renderMode();
            await renderAnnotations();
        }

        try {
            const documents = await call('mod_studymark_get_documents', {cmid: config.cmid});
            documentRecord = documents[0] || null;
            if (!documentRecord) {
                viewer.innerHTML = '<div class="studymark-empty"><p>Esta actividad todavía no tiene documento.</p></div>';
                root.querySelector('.studymark-annotations').hidden = true;
                return;
            }
            root.querySelector('[data-action=original]').href = documentRecord.url;
            await openDocument();
        } catch (error) {
            viewer.innerHTML = '<div class="alert alert-danger m-3">No se pudo procesar el documento.</div>';
            Notification.exception(error);
        }

        root.addEventListener('click', async event => {
            if (event.target.dataset.action === 'toggle-focus') { root.classList.toggle('studymark-focus'); return; }
            if (event.target.dataset.action === 'summary') { summaryMode = !summaryMode; renderMode(); return; }
            if (event.target.dataset.deleteHighlight) {
                const id = +event.target.dataset.deleteHighlight;
                await call('mod_studymark_delete_highlight', {cmid: config.cmid, highlightid: id});
                readingArticle.querySelectorAll(`[data-highlight-id="${id}"]`).forEach(mark => {
                    const parent = mark.parentNode; while (mark.firstChild) parent.insertBefore(mark.firstChild, mark); mark.remove(); parent.normalize();
                });
                highlights = highlights.filter(item => +item.id !== id);
                await renderAnnotations(); if (summaryMode) renderMode(); return;
            }
            if (event.target.dataset.deleteComment) {
                await call('mod_studymark_delete_comment', {cmid: config.cmid, commentid: +event.target.dataset.deleteComment});
                return renderAnnotations();
            }
        });
        root.querySelector('[data-region=comment-form]').addEventListener('submit', async event => {
            event.preventDefault();
            const field = event.target.querySelector('textarea');
            if (!field.value.trim()) return;
            await call('mod_studymark_create_comment', {cmid: config.cmid, documentid: documentRecord.id, highlightid: 0, groupid: 0, content: field.value});
            field.value = ''; await renderAnnotations();
        });
    }
    return {init};
});
