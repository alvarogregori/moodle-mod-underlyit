<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_studymark';
$plugin->version = 2026101803;
$plugin->requires = 2022112800;
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = '0.2.1 (MVP)';

